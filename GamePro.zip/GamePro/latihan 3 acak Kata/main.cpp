//deteksi huruf dalam kata

#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
   string kata , jawaban , tebakan ;
   char temp;
   int indeks1 , indeks2, jumlah ;

    cout << "Masukkan Sebuah Kata : "; cin >> kata ;

    cout << "Jumlah huruf dari " << kata << " adalah ";

    cout << kata.size() << endl;
    jawaban=kata;
    jumlah=kata.size();
    srand(static_cast < unsigned > (time(0)));

    for(int a=jumlah ; a>0 ; a--)
    {
        indeks1=rand()% jumlah;
        indeks2=a-1;
        temp = kata[indeks1];
        kata[indeks1]=kata[indeks2];
        kata[indeks2]= temp;
    }

    cout << "Acak Kata : ";
    for(int i=0 ; i< jumlah ; i++)
    {
        cout << kata[i];
    }
    cout << endl << endl;




return 0;
}
