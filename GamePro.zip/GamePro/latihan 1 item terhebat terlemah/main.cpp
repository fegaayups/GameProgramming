#include <iostream>
#include <string>

using namespace std;

int main()
{
    string nama_item;
    int stat, pembanding;
    string item_sebelumnya, item_terhebat, item_terlemah;
    char option;
    int i=0;

    do{
        cout << "Masukan nama item :"; cin >> nama_item;
        cout << "Masukan stat :"; cin >> stat;

        cout << "Item anda adalah :" << nama_item<<endl;
        cout << "stat :" <<stat<<endl;

        if(i==0){
            cout <<  "Item sebelumnya : Tidak ada"<<endl;
        }
        else if(i!=0){
            cout << "Item sebelumnya :"<<item_sebelumnya<<endl;
        }

        if(i==0){
            item_terhebat=nama_item;
            pembanding=stat;
        }
        else if (i!=0){
            if(stat>pembanding){
                item_terhebat=nama_item;
            }
        }
        cout <<"Item terhebat : "<<item_terhebat<<endl;

        if(i==0){
            item_terlemah=nama_item;
        }
        else if(i!=0){
            if(stat<pembanding){
                item_terlemah=nama_item;
            }
        }
        cout << "Item terlemah : "<<item_terlemah<<endl;
        cout << "Input item lagi ? (y/n) : "<<endl; cin >>option;
        item_sebelumnya=nama_item;
        i++;
    }while(option=='y');

    return 0;
}
