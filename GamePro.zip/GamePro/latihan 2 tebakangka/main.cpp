#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;
int main ()
{
  int kunci, tebakan, maks, nyawa=3;
  srand(time(NULL));

  do{
    cout << "Masukan maksimal nilai (10-100) ="; cin >> maks;
        if(maks<10 || maks>100){
        cout << "Masukan angka antara 10-100 = !!" << endl;
        cout<<endl;
        }
    }while (maks<10 || maks>100);

  cout << "silahkan tebak angka antara 0 sampai "<<maks<<endl;
  kunci = rand()% maks+1;
  cout <<"(cheat : ini adalah angka yang ditebak):"<<kunci<<endl;

  do{
    cout <<"Masukan tebakann anda :";cin >>tebakan;
        if(tebakan<kunci){
        cout << "tebakan anda terlalu kecil"<<endl;
        nyawa--;
        cout<<"tebakan anda salah, nyawa :"<<nyawa<<endl;
        }

        else if(tebakan>kunci){
        cout << "Tebakan anda terlalu besar"<<endl;
        nyawa--;
        cout << "tebakan anda salah, nyawa  : "<< nyawa<<endl;
        }

        else if(kunci == tebakan){
        cout <<"tebakan anda benar"<<endl;

        }

    }while(kunci!=tebakan && nyawa !=0 );
    return 0;
  }



